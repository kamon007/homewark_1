package th.ac.su.homework1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnCalculate = findViewById<Button>(R.id.btnCal)
        val showScore = findViewById<TextView>(R.id.showGrade)
        val inputScore = findViewById<EditText>(R.id.inputFeild)
        val showName = findViewById<TextView>(R.id.showName)

        showScore.setPadding(0,50,0,50)
        showName.setPadding(0,70,0,50)

        btnCalculate.setOnClickListener(){
            var calculate:Double = inputScore.text.toString().toDouble()
            var score = calculate
            var show = showScore

            if (score>=0 && score<50){
                show.text = "ได้เกรด F"
                show.setTextColor(Color.parseColor("#fe0000"));
            }else if (score>=50 && score<60){
                show.text = "ได้เกรด D"
                show.setTextColor(Color.parseColor("#0013ff"));
            }else if (score>=60 && score<70){
                show.text = "ได้เกรด C"
            }else if (score>=70 && score<80){
                show.text = "ได้เกรด B"
            }else if (score>=80 && score<100){
                show.text = "ได้เกรด A"
            }
        }
    }
}
